# -*- coding: utf-8 -*-
"""Дымовой тест интерфейса без монитора: все работы, все вкладки, все признаки."""
import os
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
import pygame, traceback
pygame.init()
from model import Params, TRAIT_ORDER
from labs import LABS
import ui_screens as U

screen = pygame.display.set_mode((1400, 860))
clock = pygame.time.Clock()
fails = []
for lab in LABS:
    for ci, (cond, over) in enumerate(lab["conditions"]):
        kw = dict(lab.get("base", {})); kw.update(over); kw["seed"] = 3
        try:
            obs = U.Observation(screen, lab, Params(**kw), mode="90", days_target=40)
            for _ in range(300):
                obs.sim.step()
            obs.selected = next((o for o in obs.sim.orgs), None)
            obs._take_mark(); obs._take_mark()
            for t in ("protocol", "theory", "marks"):
                obs.tab = t
                for _ in range(len(TRAIT_ORDER)):
                    obs._cycle_trait()
                    obs.draw()
            # события: движение мыши, клик по арене, перетаскивание ползунка
            for ev in (pygame.event.Event(pygame.MOUSEMOTION, pos=(300, 300), rel=(1, 1), buttons=(0,0,0)),
                       pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=(300, 300), button=1),
                       pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=(1100, 600), button=1),
                       pygame.event.Event(pygame.MOUSEMOTION, pos=(1300, 600), rel=(1,0), buttons=(1,0,0)),
                       pygame.event.Event(pygame.MOUSEBUTTONUP, pos=(1300, 600), button=1)):
                for sl in obs.sliders: sl.event(ev)
                for b in obs.buttons: b.event(ev)
                if ev.type == pygame.MOUSEBUTTONDOWN and obs.arena.collidepoint(ev.pos):
                    obs._pick(ev.pos)
            obs.draw()
        except Exception:
            fails.append(f"{lab['id']} / {cond}: {traceback.format_exc(limit=2)}")
# пустая популяция — частый источник падений
try:
    obs = U.Observation(screen, LABS[0], Params(seed=1, N_herb0=1, N_pred0=1,
                        imm_herb=0.0, imm_pred=0.0, P_max=0.0), mode="90", days_target=60)
    for _ in range(600): obs.sim.step()
    for t in ("protocol", "theory", "marks"):
        obs.tab = t; obs.draw()
    assert len(obs.sim.orgs) == 0, "популяция не вымерла — тест не сработал"
except Exception:
    fails.append("вымершая популяция: " + traceback.format_exc(limit=2))

print("ДЫМОВОЙ ТЕСТ ИНТЕРФЕЙСА:", "OK" if not fails else f"{len(fails)} ОШИБОК")
for f in fails: print(f)

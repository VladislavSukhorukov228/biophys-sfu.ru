# -*- coding: utf-8 -*-
"""Снимает экраны интерфейса без монитора — для проверки вёрстки."""
import os, sys, tempfile
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
import pygame
pygame.init()
from model import Params
from labs import LABS, LAB_BY_ID
import ui_screens as U
from ui_widgets import C

W, H = 1400, 860
screen = pygame.display.set_mode((W, H))
clock = pygame.time.Clock()
state = {"mode": "90", "seed": 7}

which = sys.argv[1] if len(sys.argv) > 1 else "obs"

if which == "menu":
    m = U.Menu(screen, state)
    screen.fill(C["bg"])
    for b in m.buttons: b.draw(screen)
    from ui_widgets import font, text
    text(screen, "ЭКОЭНЕРГЕТИКА", font(46, True), C["txt_hi"], W//2, H//2-190, "tc")
    text(screen, "лабораторный практикум по экологии и биофизике", font(15), C["txt_dim"], W//2, H//2-140, "tc")
    text(screen, "агентная модель потока энергии и естественного отбора", font(12), C["txt_dim"], W//2, H//2-118, "tc")
    text(screen, "seed = 7   (номер студента по журналу)", font(10), C["txt_dim"], W//2, H-46, "tc")
    pygame.image.save(screen, os.path.join(tempfile.gettempdir(), "menu.png"))
elif which == "labs":
    l = U.LabList(screen, LABS, state)
    from ui_widgets import font, text, panel, mix, wrap
    screen.fill(C["bg"])
    text(screen, "ЛАБОРАТОРНЫЕ РАБОТЫ", font(24, True), C["txt_hi"], W//2, 34, "tc")
    text(screen, "режим 90 минут · «ядро» — работы, пригодные как обязательные", font(11), C["txt_dim"], W//2, 68, "tc")
    for r, L in l.cards:
        accent = C["ok"] if L["core"] else C["blue"]
        panel(screen, r, fill=C["panel"], border=C["line"])
        pygame.draw.rect(screen, accent, (r.x, r.y, r.w, 3), border_radius=3)
        text(screen, L["title"], font(12, True), C["txt"], r.x+12, r.y+12)
        text(screen, L["law"], font(9), C["txt_dim"], r.x+12, r.y+30)
        text(screen, f"{len(L['conditions'])} усл. × {L['reps_90']} повт. × {L['days_90']} сут", font(9, mono=True), accent, r.x+12, r.y+48)
        text(screen, "ядро" if L["core"] else "доп.", font(9, True), accent, r.right-12, r.y+12, "tr")
        for i, ln in enumerate(wrap(L["goal"], font(9), r.w-24)[:1]):
            text(screen, ln, font(9), C["txt_dim"], r.x+12, r.y+63)
    pygame.image.save(screen, os.path.join(tempfile.gettempdir(), "labs.png"))
else:
    lab = LAB_BY_ID[sys.argv[2] if len(sys.argv) > 2 else "predprey"]
    kw = dict(lab.get("base", {})); kw.update(lab["conditions"][0][1]); kw["seed"] = 7
    obs = U.Observation(screen, lab, Params(**kw), mode="90")
    days = float(sys.argv[3]) if len(sys.argv) > 3 else 90.0
    while obs.sim.day < days:
        obs.sim.step()
    obs.selected = next((o for o in obs.sim.orgs if not o.is_pred), None)
    obs.tab = sys.argv[4] if len(sys.argv) > 4 else "protocol"
    obs.draw()
    pygame.image.save(screen, os.path.join(tempfile.gettempdir(), f"obs_{obs.tab}.png"))
print("снимок сохранён в", tempfile.gettempdir())

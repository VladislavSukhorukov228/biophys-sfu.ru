@echo off
chcp 65001 > nul
REM ============================================================================
REM  Сборка .exe для Windows. Запускать ТОЛЬКО на Windows:
REM  PyInstaller не умеет кросс-компиляцию, на Linux получится Linux-бинарник.
REM
REM  Перед первым запуском:  pip install pygame openpyxl pyinstaller
REM ============================================================================

echo.
echo  [1/3] Проверка модели перед сборкой...
python main.py --selftest
if errorlevel 1 (
    echo.
    echo  ОШИБКА: самопроверка не пройдена, сборка отменена.
    pause
    exit /b 1
)

echo.
echo  [2/3] Сборка варианта ONEDIR (папка — запускается мгновенно,
echo        реже вызывает подозрения антивируса; раздавать в ZIP)
pyinstaller --noconfirm --clean --windowed ^
    --name "Экоэнергетика" ^
    --add-data "assets;assets" ^
    --hidden-import openpyxl ^
    --exclude-module numpy --exclude-module matplotlib ^
    --exclude-module scipy --exclude-module PIL --exclude-module tkinter ^
    main.py

echo.
echo  [3/3] Сборка варианта ONEFILE (один файл — удобно, но старт 3-8 с
echo        и чаще срабатывает эвристика антивируса)
pyinstaller --noconfirm --clean --windowed --onefile ^
    --name "Экоэнергетика-один-файл" ^
    --add-data "assets;assets" ^
    --hidden-import openpyxl ^
    --exclude-module numpy --exclude-module matplotlib ^
    --exclude-module scipy --exclude-module PIL --exclude-module tkinter ^
    main.py

echo.
echo  Готово. Результаты в папке dist\
echo    dist\Экоэнергетика\           — вариант ONEDIR (упакуйте в ZIP)
echo    dist\Экоэнергетика-один-файл.exe — вариант ONEFILE
echo.
echo  ОБЯЗАТЕЛЬНО проверьте сборку на компьютере БЕЗ Python,
echo  желательно в том самом классе, где будет занятие.
pause

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ЭКОЭНЕРГЕТИКА — лабораторный практикум по экологии и биофизике
================================================================
Агентная модель потока энергии и естественного отбора в экосистеме.

Пока реализован только пакетный (расчётный) режим. Графический режим
наблюдения добавляется отдельным модулем ui_*.py и на расчёт не влияет.

Примеры:
  python main.py --list
  python main.py --lab logistic --mode 90
  python main.py --lab q10 --mode 180 --seed 17
  python main.py --lab kleiber --mode 90 --probe
  python main.py --selftest
"""

import argparse, sys, time


def cmd_list():
    from labs import LABS
    print("\nДоступные лабораторные работы:\n")
    for L in LABS:
        mark = "  ядро " if L["core"] else "  доп. "
        print(f"{mark} {L['id']:<10} {L['title']}")
        print(f"          90 мин: {L['days_90']:>3} сут × {L['reps_90']} повт. × "
              f"{len(L['conditions'])} усл.   |   "
              f"180 мин: {L['days_180']:>3} сут × {L['reps_180']} повт.")
    print("\n«ядро» — работа пригодна как обязательная на 90 минут.\n")


def cmd_selftest():
    """Проверка, что модель физически корректна. Запускать после любой правки."""
    from model import Params, Simulation, probe_metabolism
    import math, statistics
    ok = True

    print("1. Сохранение энергии ...", end=" ")
    errs = []
    for seed in (1, 2, 3):
        s = Simulation(Params(seed=seed)); s.run(80)
        errs.append(abs(s.balance_error()))
    worst = max(errs)
    print(f"максимальная невязка {worst:.2e}", "OK" if worst < 1e-9 else "ОШИБКА")
    ok &= worst < 1e-9

    print("2. Воспроизводимость по seed ...", end=" ")
    a = Simulation(Params(seed=42)); a.run(50)
    b = Simulation(Params(seed=42)); b.run(50)
    same = a.log[-1] == b.log[-1]
    print("OK" if same else "ОШИБКА")
    ok &= same

    print("3. Восстановление показателя Клайбера ...", end=" ")
    rows = probe_metabolism(Params(), n=40)
    x = [math.log10(r["M"]) for r in rows]
    y = [math.log10(r["B_основной"]) for r in rows]
    mx, my = statistics.fmean(x), statistics.fmean(y)
    beta = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y)) / sum((xi - mx) ** 2 for xi in x)
    print(f"beta = {beta:.4f} (ожидается 0.7500)",
          "OK" if abs(beta - 0.75) < 0.01 else "ОШИБКА")
    ok &= abs(beta - 0.75) < 0.01

    print("4. Ёмкость среды растёт с продуктивностью ...", end=" ")
    ks = []
    for pm in (165.0, 330.0):
        s = Simulation(Params(seed=1, P_max=pm, N_pred0=0, imm_pred=0.0)); s.run(200)
        ks.append(statistics.fmean([r["N_herb"] for r in s.log[-60:]]))
    ratio = ks[1] / ks[0]
    print(f"K удвоение продукции -> ×{ratio:.2f}", "OK" if 1.6 < ratio < 2.4 else "ОШИБКА")
    ok &= 1.6 < ratio < 2.4

    print("5. Сходимость по шагу интегрирования ...", end=" ")
    res = []
    for dt in (0.10, 0.05):
        vals = []
        for sd in (1, 2):
            s = Simulation(Params(seed=sd, dt=dt, N_pred0=0, imm_pred=0.0)); s.run(120)
            vals.append(statistics.fmean([r["N_herb"] for r in s.log[-30:]]))
        res.append(statistics.fmean(vals))
    drift = abs(res[1] - res[0]) / res[0]
    print(f"расхождение dt=0.10 и dt=0.05: {drift*100:.1f} %",
          "OK" if drift < 0.08 else "ОШИБКА")
    ok &= drift < 0.08

    print("6. Физическая непротиворечивость состояний ...", end=" ")
    s = Simulation(Params(seed=5)); s.run(100)
    bad = []
    if any(o.E < 0 for o in s.orgs): bad.append("отрицательный резерв")
    if any(o.M <= 0 for o in s.orgs): bad.append("неположительная масса")
    if len(s.orgs) > s.p.N_max: bad.append("превышен потолок численности")
    if s.detritus < 0: bad.append("отрицательный детрит")
    if any(v != v for r in s.log for v in r.values() if isinstance(v, float)):
        bad.append("NaN в журнале")
    print("OK" if not bad else "ОШИБКА: " + ", ".join(bad))
    ok &= not bad

    print("7. Все восемь работ запускаются ...", end=" ")
    from labs import LABS
    from batch import run_batch
    failed = []
    for L in LABS:
        try:
            run_batch(L, mode="90", base_seed=1, days=25, reps=1)
        except Exception as e:
            failed.append(f"{L['id']}: {e}")
    print("OK" if not failed else "ОШИБКА: " + "; ".join(failed))
    ok &= not failed

    print("\nИТОГ:", "все проверки пройдены" if ok else "ЕСТЬ ОШИБКИ")
    return 0 if ok else 1


def cmd_run(args):
    from model import Params, probe_metabolism, probe_functional_response
    from labs import LAB_BY_ID, lab_plan
    from batch import run_batch, aggregate, compare_conditions
    from export import export_xlsx, output_dir

    lab = LAB_BY_ID.get(args.lab)
    if lab is None:
        print(f"Работа '{args.lab}' не найдена. Список: python main.py --list")
        return 1

    days, reps = lab_plan(lab, args.mode)
    if args.days: days = args.days
    if args.reps: reps = args.reps
    total = len(lab["conditions"]) * reps

    print(f"\n{lab['title']}")
    print(f"Режим {args.mode} мин: {len(lab['conditions'])} условий × {reps} "
          f"повторностей × {days} усл. сут = {total} прогонов")
    print(f"Базовый seed: {args.seed}\n")

    t0 = time.time()

    def progress(frac, msg):
        bar = "#" * int(frac * 30)
        sys.stdout.write(f"\r  [{bar:<30}] {frac*100:5.1f}%  {msg:<34}")
        sys.stdout.flush()

    runs, summ, logs, inds, sels = run_batch(
        lab, mode=args.mode, base_seed=args.seed,
        days=days, reps=reps, progress=progress)
    print(f"\n  расчёт завершён за {time.time()-t0:.0f} с\n")

    agg = aggregate(summ)
    cmp_rows = []
    for key in ("N_herb_ср", "N_pred_ср", "троф_эффективность", "h2_скорость"):
        cmp_rows += compare_conditions(summ, key)

    probe = None
    if args.probe or lab["id"] == "kleiber":
        probe = probe_metabolism(Params(**lab.get("base", {})), n=40)
    if lab["id"] == "holling":
        probe = probe_functional_response(Params(**lab.get("base", {})), days=50)

    paths = export_xlsx(lab, args.mode, days, reps,
                        [r[2].p for r in runs], summ, agg,
                        logs, inds, sels, cmp_rows, probe)

    print("Сводка по условиям:")
    for row in agg:
        m = row.get("N_herb_ср (среднее)")
        sd = row.get("N_herb_ср (СКО)")
        ci = row.get("N_herb_ср (±95%)")
        line = f"  {row['условие']:<32} N_тр = {m:6.1f}" if m is not None else f"  {row['условие']:<32}"
        if sd is not None:
            line += f" ± {sd:5.1f} (95 % ДИ ±{ci:.1f})" if ci else f" ± {sd:5.1f}"
        print(line)

    print("\nФайлы сохранены:")
    for p in paths:
        print("  " + p)
    print()
    return 0


def cmd_ui(seed=1):
    """Графический режим: меню -> выбор работы -> наблюдение или расчёт."""
    import pygame
    pygame.init()
    try:
        pygame.mixer.quit()          # звук не нужен, а на части машин мешает
    except Exception:
        pass
    info = pygame.display.Info()
    W = min(info.current_w - 60, 1600)
    H = min(info.current_h - 90, 900)
    screen = pygame.display.set_mode((max(W, 1200), max(H, 780)))
    pygame.display.set_caption("Экоэнергетика — лабораторный практикум")
    clock = pygame.time.Clock()

    from model import Params
    from labs import LABS, lab_plan
    from ui_screens import Menu, LabList, Observation
    from ui_widgets import C, font, text, panel

    state = {"mode": "90", "seed": seed}

    def batch_screen(lab):
        """Расчёт серии с индикатором: считается быстро и без отрисовки."""
        from batch import run_batch, aggregate, compare_conditions
        from export import export_xlsx
        days, reps = lab_plan(lab, state["mode"])
        status = {"frac": 0.0, "msg": "подготовка"}

        def draw():
            screen.fill(C["bg"])
            w, h = screen.get_size()
            text(screen, lab["title"], font(20, True), C["txt_hi"], w // 2, h // 2 - 120, "tc")
            text(screen, f"{len(lab['conditions'])} условий × {reps} повторностей × {days} усл. сут",
                 font(12), C["txt_dim"], w // 2, h // 2 - 86, "tc")
            bar = pygame.Rect(w // 2 - 300, h // 2 - 20, 600, 16)
            pygame.draw.rect(screen, C["panel"], bar, border_radius=8)
            pygame.draw.rect(screen, C["blue"],
                             (bar.x, bar.y, int(bar.w * status["frac"]), bar.h), border_radius=8)
            text(screen, f"{status['frac']*100:.0f} %  —  {status['msg']}",
                 font(11), C["txt_dim"], w // 2, h // 2 + 12, "tc")
            text(screen, "Расчёт идёт без отрисовки, поэтому во много раз быстрее наблюдения.",
                 font(10), C["txt_dim"], w // 2, h // 2 + 60, "tc")
            pygame.display.flip()

        def progress(frac, msg):
            status["frac"] = frac; status["msg"] = msg
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    raise KeyboardInterrupt
            draw()

        draw()
        try:
            runs, summ, logs, inds, sels = run_batch(
                lab, mode=state["mode"], base_seed=state["seed"], progress=progress)
        except KeyboardInterrupt:
            return
        status["msg"] = "выгрузка в файл"; draw()
        agg = aggregate(summ)
        cmp_rows = []
        for k in ("N_herb_ср", "N_pred_ср", "троф_эффективность", "h2_скорость"):
            cmp_rows += compare_conditions(summ, k)
        probe = None
        if lab["id"] == "kleiber":
            from model import probe_metabolism
            probe = probe_metabolism(Params(**lab.get("base", {})), n=40)
        elif lab["id"] == "holling":
            from model import probe_functional_response
            probe = probe_functional_response(Params(**lab.get("base", {})), days=50)
        paths = export_xlsx(lab, state["mode"], days, reps, [r[2].p for r in runs],
                            summ, agg, logs, inds, sels, cmp_rows, probe)

        waiting = True
        while waiting:
            for ev in pygame.event.get():
                if ev.type in (pygame.QUIT, pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                    waiting = False
            screen.fill(C["bg"])
            w, h = screen.get_size()
            text(screen, "РАСЧЁТ ЗАВЕРШЁН", font(24, True), C["ok"], w // 2, h // 2 - 120, "tc")
            r = pygame.Rect(w // 2 - 420, h // 2 - 70, 840, 120)
            panel(screen, r)
            yy = r.y + 14
            text(screen, "Файл с результатами:", font(11), C["txt_dim"], r.x + 16, yy); yy += 18
            for pth in paths:
                text(screen, pth, font(11, mono=True), C["txt"], r.x + 16, yy); yy += 18
            yy += 6
            text(screen, "Листы: Методика · Сводка · Прогоны · Данные · Особи · Отбор",
                 font(10), C["txt_dim"], r.x + 16, yy)
            text(screen, "любая клавиша — продолжить", font(10), C["txt_dim"],
                 w // 2, h // 2 + 90, "tc")
            pygame.display.flip()
            clock.tick(60)

    while True:
        choice = Menu(screen, state).run(clock)
        if choice in (None, "quit"):
            break
        lab = LabList(screen, LABS, state).run(clock)
        if lab is None:
            continue
        if choice == "batch":
            batch_screen(lab)
            continue
        kw = dict(lab.get("base", {}))
        kw.update(lab["conditions"][0][1])
        kw["seed"] = state["seed"]
        days, _ = lab_plan(lab, state["mode"])
        obs = Observation(screen, lab, Params(**kw), mode=state["mode"], days_target=days)
        if obs.run(clock) == "quit":
            break
    pygame.quit()
    return 0


def main():
    ap = argparse.ArgumentParser(description="Экоэнергетика: лабораторный практикум")
    ap.add_argument("--list", action="store_true", help="список работ")
    ap.add_argument("--selftest", action="store_true", help="проверка корректности модели")
    ap.add_argument("--lab", help="идентификатор работы")
    ap.add_argument("--mode", default="90", choices=["90", "180"], help="режим занятия")
    ap.add_argument("--seed", type=int, default=1, help="базовый seed (номер студента)")
    ap.add_argument("--days", type=int, help="переопределить длительность, усл. сут")
    ap.add_argument("--reps", type=int, help="переопределить число повторностей")
    ap.add_argument("--probe", action="store_true", help="добавить стенд метаболизма")
    ap.add_argument("--cli", action="store_true", help="только расчёт, без графики")
    args = ap.parse_args()

    if args.list:
        cmd_list(); return 0
    if args.selftest:
        return cmd_selftest()
    if args.lab:
        return cmd_run(args)
    if args.cli:
        ap.print_help(); return 0
    try:
        return cmd_ui(seed=args.seed)
    except ImportError:
        print("pygame не установлен — доступен только расчётный режим.\n")
        ap.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
